from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista_notatek, name='lista'),
    path('dodaj/', views.dodaj_notatke, name='dodaj'),
    path('<int:pk>/', views.szczegoly_notatki, name='szczegoly'),
    path('edytuj/<int:pk>/', views.edytuj_notatke, name='edytuj'),
]