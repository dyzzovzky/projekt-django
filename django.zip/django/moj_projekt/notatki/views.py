from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from .models import Notatka
from .forms import NotatkaForm


def lista_notatek(request):
    notatki = Notatka.objects.all()

    paginator = Paginator(notatki, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(
        request,
        'notatki/lista.html',
        {'page_obj': page_obj}
    )


def szczegoly_notatki(request, pk):
    notatka = get_object_or_404(Notatka, pk=pk)

    return render(
        request,
        'notatki/szczegoly.html',
        {'notatka': notatka}
    )


def dodaj_notatke(request):
    if request.method == 'POST':
        form = NotatkaForm(request.POST)

        if form.is_valid():
            notatka = form.save(commit=False)
            notatka.autor = request.user
            notatka.save()

            return redirect('lista')

    else:
        form = NotatkaForm()

    return render(
    request,
    'notatki/formularz.html',
    {'form': form}
)


def edytuj_notatke(request, pk):
    notatka = get_object_or_404(Notatka, pk=pk)

    if request.method == 'POST':
        form = NotatkaForm(
            request.POST,
            instance=notatka
        )

        if form.is_valid():
            form.save()
            return redirect('lista')

    else:
        form = NotatkaForm(instance=notatka)

    return render(
        request,
        'notatki/formularz.html',
        {'form': form}
    )