from django.db import models
from django.contrib.auth.models import User


class Notatka(models.Model):
    PRIORYTETY = [
        ('W', 'Ważne'),
        ('S', 'Średnie'),
        ('N', 'Niskie'),
    ]

    tytul = models.CharField(max_length=200)
    tresc = models.TextField()
    data_utworzenia = models.DateField(auto_now_add=True)
    autor = models.ForeignKey(User, on_delete=models.CASCADE)
    priorytet = models.CharField(
        max_length=1,
        choices=PRIORYTETY,
        default='S'
    )
    

    def __str__(self):
        return self.tytul

    class Meta:
        ordering = ['priorytet', '-data_utworzenia']